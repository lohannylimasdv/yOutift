import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { image_url } = body;
    if (!image_url) return Response.json({ error: 'image_url é obrigatório' }, { status: 400 });

    const prompt = `Você é um especialista em moda e vestuário. Analise a imagem da peça de roupa com atenção aos detalhes.

Identifique com precisão:
1. **Categoria** — classifique rigorosamente:
   - "top": camisetas, camisas, polos, regatas, blusas leves (peças que cobrem o tronco, vestem por baixo de jaquetas)
   - "bottom": calças, jeans, shorts, bermudas, saias (peças que cobrem da cintura para baixo)
   - "outerwear": jaquetas, casacos, blazers, moletons, cardigans, coletes (peças de cima que se vestem sobre o top)
   - "dress": vestidos e macacões (peça única que cobre tronco e pernas)
   - "shoes": tênis, sapatos, botas, sandálias, chinelos (calçados)
   - "accessory": chapéus, bonés, toucas, bandanas, óculos, cintos, bolsas, relógios, lenços (acessórios e complementos)
   - "other": qualquer peça que não se enquadre acima
2. **Cor predominante** — a cor principal visível (ex: "azul marinho", "verde oliva", "preto fosco", "branco off-white"). Se houver estampa, descreva cor base + estampa.
3. **Família de cor** — agrupe na família: neutral, black, white, red, orange, yellow, green, blue, purple, pink, brown, gray, multicolor
4. **Estilo** — casual, formal, sporty, streetwear, bohemian, classic, trendy, minimalist, vintage
5. **Estação adequada** — em qual estação a peça é mais usada: spring, summer, fall, winter, all
6. **Nome curto** — nome descritivo e natural em português (ex: "Camiseta azul marinho", "Jaqueta jeans clara", "Tênis branco casual")
7. **Descrição** — descrição objetiva: tipo, tecido aparente, caimento, detalhes relevantes (gola, manga, estampa, textura), em 1-2 frases.

Seja preciso na categoria — é fundamental para o sistema de combinações. Responda apenas em JSON.`;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      file_urls: [image_url],
      response_json_schema: {
        type: "object",
        properties: {
          name: { type: "string" },
          category: { type: "string", enum: ["top", "bottom", "outerwear", "dress", "shoes", "accessory", "other"] },
          color: { type: "string" },
          color_family: { type: "string", enum: ["neutral", "black", "white", "red", "orange", "yellow", "green", "blue", "purple", "pink", "brown", "gray", "multicolor"] },
          style: { type: "string", enum: ["casual", "formal", "sporty", "streetwear", "bohemian", "classic", "trendy", "minimalist", "vintage"] },
          season: { type: "string", enum: ["spring", "summer", "fall", "winter", "all"] },
          ai_description: { type: "string" }
        },
        required: ["name", "category", "color", "color_family", "style", "season", "ai_description"]
      }
    });

    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}