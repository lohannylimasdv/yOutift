import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { items, occasion } = body;
    if (!items || !Array.isArray(items) || items.length < 2) {
      return Response.json({ error: 'Envie pelo menos 2 peças' }, { status: 400 });
    }

    const itemsSummary = items.map((it, i) =>
      `Peça ${i + 1} (ID: ${it.id}): ${it.name} | categoria: ${it.category} | cor: ${it.color} (${it.color_family}) | estilo: ${it.style} | estação: ${it.season}`
    ).join('\n');

    // Agrupa peças por categoria para orientar a IA
    const tops = items.filter(it => it.category === 'top');
    const bottoms = items.filter(it => it.category === 'bottom');
    const shoes = items.filter(it => it.category === 'shoes');
    const dresses = items.filter(it => it.category === 'dress');
    const outerwears = items.filter(it => it.category === 'outerwear');
    const accessories = items.filter(it => it.category === 'accessory');

    const disponibilidade = `Disponível no guarda-roupa:
- Tops (camisetas/camisas): ${tops.length}
- Bottoms (calças/shorts/saias): ${bottoms.length}
- Sapatos: ${shoes.length}
- Vestidos: ${dresses.length}
- Outerwear (jaquetas/casacos/blusas): ${outerwears.length}
- Acessórios (chapeus/bones/toucas/bandanas/outros): ${accessories.length}`;

    const prompt = `Você é um estilista profissional. Com base nas peças do guarda-roupa do usuário, monte 3 combinações de outfit${occasion ? ` para ocasião "${occasion}"` : ''}.

Peças disponíveis:
${itemsSummary}

${disponibilidade}

REGRAS OBRIGATÓRIAS para cada outfit:
1. Cada outfit deve ter EXATAMENTE 1 (um) top, 1 (um) bottom e 1 (um) shoes — a base do look.
   - Exceção: se houver vestidos (dress) disponíveis, um outfit pode usar 1 vestido + 1 sapato (sem top/bottom separados).
2. NUNCA repita a mesma categoria em um outfit. Por exemplo: 2 tops, 2 bottoms ou 2 sapatos no mesmo look é PROIBIDO.
3. Blusa/jaqueta (outerwear), chapéu/boné/touca/bandana e outros acessórios NÃO são obrigatórios — inclua-os apenas em ALGUNS outfits, de forma aleatória, quando houver disponível e fizer sentido estético. Nunca inclua mais de 1 outerwear ou mais de 1 acessório por look.
4. As peças devem combinar em cor e estilo. Priorize harmonia cromática (cores complementares ou análogas, paleta neutra + 1 ponto de cor) e coerência de estilo/estação.
5. Use apenas peças que existem no guarda-roupa (pelos IDs listados).
6. Dê nomes criativos e em português a cada look.

Para cada outfit retorne:
- name: nome criativo do look (em português)
- item_ids: array com os IDs reais das peças escolhidas (use o campo ID, não o número sequencial)
- occasion: ocasião (casual, work, party, date, travel, workout, formal, everyday)
- style: estilo predominante do look
- ai_suggestion: breve justificativa da combinação (harmonia de cor, estilo, ocasião e quais peças extras foram adicionadas, se houver)

Se não houver peças suficientes para um outfit completo (1 top + 1 bottom + 1 shoes), gere apenas os outfits possíveis.

Responda apenas em JSON com array "outfits".`;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          outfits: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                item_ids: { type: "array", items: { type: "string" } },
                occasion: { type: "string", enum: ["casual", "work", "party", "date", "travel", "workout", "formal", "everyday"] },
                style: { type: "string" },
                ai_suggestion: { type: "string" }
              },
              required: ["name", "item_ids", "occasion", "style", "ai_suggestion"]
            }
          }
        },
        required: ["outfits"]
      }
    });

    // IDs já vêm reais da IA; valida contra os IDs disponíveis
    const validIds = new Set(items.map(it => it.id));
    const itemById = new Map(items.map(it => [it.id, it]));
    // Garante no máximo 1 peça por categoria em cada outfit (segurança)
    const outfits = (result.outfits || []).map(o => {
      const seenIds = new Set();
      const seenCats = new Set();
      const item_ids = (o.item_ids || [])
        .filter(id => {
          if (!validIds.has(id) || seenIds.has(id)) return false;
          const cat = itemById.get(id)?.category;
          if (cat && seenCats.has(cat)) return false; // bloqueia categoria repetida
          seenIds.add(id);
          if (cat) seenCats.add(cat);
          return true;
        });
      return {
        name: o.name,
        item_ids,
        occasion: o.occasion,
        style: o.style,
        ai_suggestion: o.ai_suggestion,
        is_ai_generated: true
      };
    }).filter(o => o.item_ids.length >= 2);

    return Response.json({ outfits });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}