import React from 'react';
import { Image } from '@/components/ui/image';
import { Shirt, Palette, Tag } from 'lucide-react';

const colorFamilyHex = {
  neutral: '#a8a29e',
  black: '#1a1a1a',
  white: '#f5f5f5',
  red: '#ef4444',
  orange: '#f97316',
  yellow: '#eab308',
  green: '#22c55e',
  blue: '#3b82f6',
  purple: '#a855f7',
  pink: '#ec4899',
  brown: '#92400e',
  gray: '#6b7280',
  multicolor: 'linear-gradient(135deg, #ef4444, #eab308, #22c55e, #3b82f6, #a855f7)',
};

const categoryLabels = {
  top: 'Tops',
  bottom: 'Calças/Saias',
  outerwear: 'Casacos',
  dress: 'Vestidos',
  shoes: 'Calçados',
  accessory: 'Acessórios',
  other: 'Outros',
};

const styleLabels = {
  casual: 'Casual',
  formal: 'Formal',
  sporty: 'Esportivo',
  streetwear: 'Streetwear',
  bohemian: 'Boêmio',
  classic: 'Clássico',
  trendy: 'Trendy',
  minimalist: 'Minimalista',
  vintage: 'Vintage',
};

export default function ClothingCard({ item, onClick }) {
  if (!item) return null;
  return (
    <button
      onClick={onClick}
      className="group relative overflow-hidden rounded-2xl bg-card border border-border shadow-sm hover:shadow-md transition-all text-left w-full"
    >
      <div className="aspect-[3/4] overflow-hidden bg-muted">
        {item.image_url ? (
          <Image
            src={item.image_url}
            alt={item.name}
            className="w-full h-full"
            fittingType="fill"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Shirt className="w-10 h-10 text-muted-foreground/40" />
          </div>
        )}
      </div>
      <div className="absolute top-2 right-2 flex gap-1.5">
        <span
          className="w-5 h-5 rounded-full border-2 border-white/80 shadow-sm"
          style={{ background: colorFamilyHex[item.color_family] || '#a8a29e' }}
        />
      </div>
      <div className="p-3 space-y-1">
        <p className="text-sm font-medium text-foreground truncate">{item.name}</p>
        <div className="flex items-center gap-2 flex-wrap">
          <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
            <Tag className="w-2.5 h-2.5" />
            {categoryLabels[item.category] || item.category}
          </span>
          <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
            <Palette className="w-2.5 h-2.5" />
            {styleLabels[item.style] || item.style}
          </span>
        </div>
      </div>
    </button>
  );
}