import React from 'react';
import { Image } from '@/components/ui/image';
import { Sparkles, Calendar } from 'lucide-react';

const occasionLabels = {
  casual: 'Casual',
  work: 'Trabalho',
  party: 'Festa',
  date: 'Encontro',
  travel: 'Viagem',
  workout: 'Treino',
  formal: 'Formal',
  everyday: 'Dia a dia',
};

export default function OutfitCard({ outfit, items = [], onClick }) {
  return (
    <button
      onClick={onClick}
      className="group w-full text-left rounded-2xl bg-card border border-border shadow-sm hover:shadow-md transition-all overflow-hidden"
    >
      <div className="flex gap-2 p-3 overflow-x-auto scrollbar-hide">
        {items.length > 0 ? (
          items.map((it, i) => (
            <div key={i} className="flex-shrink-0 w-20 h-24 rounded-xl overflow-hidden bg-muted">
              {it?.image_url && (
                <Image src={it.image_url} alt={it?.name || ''} className="w-full h-full" fittingType="fill" />
              )}
            </div>
          ))
        ) : (
          <div className="w-full h-24 flex items-center justify-center text-muted-foreground text-sm">
            Sem peças
          </div>
        )}
      </div>
      <div className="px-3 pb-3 space-y-1.5">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-semibold text-foreground truncate">{outfit.name}</p>
          {outfit.is_ai_generated && (
            <Sparkles className="w-3.5 h-3.5 text-primary flex-shrink-0" />
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-accent text-accent-foreground">
            <Calendar className="w-2.5 h-2.5" />
            {occasionLabels[outfit.occasion] || outfit.occasion}
          </span>
          {outfit.style && (
            <span className="text-[10px] text-muted-foreground truncate">{outfit.style}</span>
          )}
        </div>
      </div>
    </button>
  );
}