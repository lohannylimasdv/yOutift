import React from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Home, Sparkles, Plus, User } from 'lucide-react';
import ThemeToggle from './ThemeToggle';

const navItems = [
  { path: '/', label: 'Guarda-roupa', icon: Home },
  { path: '/outfits', label: 'Looks', icon: Sparkles },
  { path: '/add', label: 'Adicionar', icon: Plus, isCenter: true },
  { path: '/profile', label: 'Perfil', icon: User },
];

export default function Layout() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 glass border-b border-border">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">y</span>
            </div>
            <h1 className="text-lg font-bold font-display tracking-tight text-foreground">
              yOutfit
            </h1>
          </div>
          <ThemeToggle />
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 max-w-2xl mx-auto w-full px-4 py-4 pb-28">
        <Outlet />
      </main>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 glass border-t border-border">
        <div className="max-w-2xl mx-auto px-4 py-2 flex items-center justify-around">
          {navItems.map(({ path, label, icon: Icon, isCenter }) => {
            const active = location.pathname === path;
            if (isCenter) {
              return (
                <button
                  key={path}
                  onClick={() => navigate(path)}
                  className="flex flex-col items-center -mt-6"
                  aria-label={label}
                >
                  <span className="w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/30 transition-transform active:scale-95">
                    <Icon className="w-6 h-6" />
                  </span>
                </button>
              );
            }
            return (
              <button
                key={path}
                onClick={() => navigate(path)}
                className={`flex flex-col items-center gap-1 px-3 py-1.5 transition-colors ${
                  active ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-medium">{label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}