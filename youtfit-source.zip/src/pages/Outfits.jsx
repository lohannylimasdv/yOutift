import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Sparkles, Loader2, Wand2, Calendar } from 'lucide-react';
import OutfitCard from '@/components/OutfitCard';
import EmptyState from '@/components/EmptyState';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const occasions = [
  { value: '', label: 'Qualquer ocasião' },
  { value: 'casual', label: 'Casual' },
  { value: 'work', label: 'Trabalho' },
  { value: 'party', label: 'Festa' },
  { value: 'date', label: 'Encontro' },
  { value: 'formal', label: 'Formal' },
  { value: 'travel', label: 'Viagem' },
  { value: 'workout', label: 'Treino' },
];

export default function Outfits() {
  const [outfits, setOutfits] = useState(null);
  const [items, setItems] = useState([]);
  const [generating, setGenerating] = useState(false);
  const [occasion, setOccasion] = useState('');
  const navigate = useNavigate();

  const loadData = async () => {
    try {
      const [outfitData, itemData] = await Promise.all([
        base44.entities.Outfit.list('-created_date', 100),
        base44.entities.ClothingItem.list('-created_date', 200),
      ]);
      setOutfits(outfitData);
      setItems(itemData);
    } catch (e) {
      setOutfits([]);
    }
  };

  useEffect(() => { loadData(); }, []);

  const itemsById = {};
  items.forEach(it => { itemsById[it.id] = it; });

  const handleGenerate = async () => {
    if (items.length < 2) return;
    setGenerating(true);
    try {
      const response = await base44.functions.invoke('generateOutfits', {
        items: items.map(it => ({
          id: it.id,
          name: it.name,
          category: it.category,
          color: it.color,
          color_family: it.color_family,
          style: it.style,
          season: it.season,
        })),
        occasion: occasion || undefined,
      });
      const generated = response.data?.outfits || [];
      // Save generated outfits
      for (const o of generated) {
        await base44.entities.Outfit.create(o);
      }
      await loadData();
    } catch (e) {
      console.error(e);
    } finally {
      setGenerating(false);
    }
  };

  const loading = outfits === null;

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold text-foreground">Meus looks</h2>
        <p className="text-sm text-muted-foreground">
          {loading ? 'Carregando...' : `${(outfits || []).length} looks salvos`}
        </p>
      </div>

      {/* AI Generator */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-primary/10 to-accent border border-primary/20 space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
            <Wand2 className="w-4 h-4 text-primary-foreground" />
          </div>
          <div>
            <p className="font-semibold text-foreground text-sm">Gerar looks com IA</p>
            <p className="text-xs text-muted-foreground">Combina suas peças automaticamente</p>
          </div>
        </div>
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {occasions.map(o => (
            <button
              key={o.value}
              onClick={() => setOccasion(o.value)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                occasion === o.value
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground'
              }`}
            >
              {o.label}
            </button>
          ))}
        </div>
        <Button
          onClick={handleGenerate}
          disabled={generating || items.length < 2}
          className="w-full gap-2"
        >
          {generating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Criando combinações...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              {items.length < 2 ? 'Adicione 2+ peças' : 'Gerar 3 looks'}
            </>
          )}
        </Button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      ) : (outfits || []).length === 0 ? (
        <EmptyState
          icon={Sparkles}
          title="Nenhum look ainda"
          description="Gere combinações com IA a partir das peças do seu guarda-roupa."
        />
      ) : (
        <div className="space-y-3">
          {(outfits || []).map(o => (
            <OutfitCard
              key={o.id}
              outfit={o}
              items={(o.item_ids || []).map(id => itemsById[id]).filter(Boolean)}
              onClick={() => navigate(`/outfit/${o.id}`)}
            />
          ))}
        </div>
      )}
    </div>
  );
}