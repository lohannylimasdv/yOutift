import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Shirt, Plus, Filter, Loader2 } from 'lucide-react';
import ClothingCard from '@/components/ClothingCard';
import EmptyState from '@/components/EmptyState';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const categoryFilters = [
  { value: 'all', label: 'Tudo' },
  { value: 'top', label: 'Tops' },
  { value: 'bottom', label: 'Calças' },
  { value: 'outerwear', label: 'Casacos' },
  { value: 'dress', label: 'Vestidos' },
  { value: 'shoes', label: 'Calçados' },
  { value: 'accessory', label: 'Acessórios' },
];

const colorFilters = [
  { value: 'all', label: 'Todas cores' },
  { value: 'neutral', label: 'Neutras' },
  { value: 'black', label: 'Pretas' },
  { value: 'white', label: 'Brancas' },
  { value: 'red', label: 'Vermelhas' },
  { value: 'blue', label: 'Azuis' },
  { value: 'green', label: 'Verdes' },
  { value: 'purple', label: 'Roxas' },
  { value: 'pink', label: 'Rosas' },
  { value: 'brown', label: 'Marrons' },
  { value: 'gray', label: 'Cinza' },
];

export default function Home() {
  const [items, setItems] = useState(null);
  const [filter, setFilter] = useState('all');
  const [colorFilter, setColorFilter] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const navigate = useNavigate();

  const loadItems = async () => {
    try {
      const data = await base44.entities.ClothingItem.list('-created_date', 200);
      setItems(data);
    } catch (e) {
      setItems([]);
    }
  };

  useEffect(() => { loadItems(); }, []);

  const filtered = (items || []).filter(it => {
    const catOk = filter === 'all' || it.category === filter;
    const colorOk = colorFilter === 'all' || it.color_family === colorFilter;
    return catOk && colorOk;
  });

  const loading = items === null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Meu guarda-roupa</h2>
          <p className="text-sm text-muted-foreground">
            {loading ? 'Carregando...' : `${(items || []).length} peças`}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowFilters(s => !s)}
          className="gap-1.5"
        >
          <Filter className="w-4 h-4" />
          Filtros
        </Button>
      </div>

      {showFilters && (
        <div className="space-y-3 p-3 rounded-xl bg-card border border-border animate-in fade-in slide-in-from-top-2 duration-200">
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">Categoria</p>
            <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
              {categoryFilters.map(f => (
                <button
                  key={f.value}
                  onClick={() => setFilter(f.value)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                    filter === f.value
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-secondary-foreground'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">Cor</p>
            <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
              {colorFilters.map(f => (
                <button
                  key={f.value}
                  onClick={() => setColorFilter(f.value)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                    colorFilter === f.value
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-secondary-foreground'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Shirt}
          title="Seu guarda-roupa está vazio"
          description="Tire fotos das suas roupas ou suba imagens da galeria. A IA vai categorizar tudo pra você."
          action={
            <Button onClick={() => navigate('/add')} className="gap-2">
              <Plus className="w-4 h-4" />
              Adicionar peça
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {filtered.map(item => (
            <ClothingCard key={item.id} item={item} onClick={() => navigate(`/item/${item.id}`)} />
          ))}
        </div>
      )}
    </div>
  );
}