import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useParams, useNavigate } from 'react-router-dom';
import { Image } from '@/components/ui/image';
import { ArrowLeft, Trash2, Loader2, Sparkles, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';

const occasionLabels = {
  casual: 'Casual', work: 'Trabalho', party: 'Festa', date: 'Encontro',
  travel: 'Viagem', workout: 'Treino', formal: 'Formal', everyday: 'Dia a dia',
};

export default function OutfitDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [outfit, setOutfit] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.Outfit.get(id);
        setOutfit(data);
        if (data?.item_ids?.length) {
          const fetched = await Promise.all(
            data.item_ids.map(itemId => base44.entities.ClothingItem.get(itemId).catch(() => null))
          );
          setItems(fetched.filter(Boolean));
        }
      } catch (e) {
        setOutfit(null);
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await base44.entities.Outfit.delete(id);
      navigate('/outfits');
    } catch (e) {
      setDeleting(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;
  }
  if (!outfit) {
    return <p className="text-center text-muted-foreground py-20">Look não encontrado</p>;
  }

  return (
    <div className="space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="w-4 h-4" /> Voltar
      </button>

      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-foreground">{outfit.name}</h2>
          {outfit.is_ai_generated && <Sparkles className="w-4 h-4 text-primary" />}
        </div>
        <div className="flex items-center gap-2 mt-1">
          <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-accent text-accent-foreground">
            <Calendar className="w-3 h-3" />
            {occasionLabels[outfit.occasion] || outfit.occasion}
          </span>
          {outfit.style && <span className="text-xs text-muted-foreground capitalize">{outfit.style}</span>}
        </div>
      </div>

      {outfit.ai_suggestion && (
        <div className="p-4 rounded-xl bg-accent/50 border border-primary/20">
          <div className="flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
            <p className="text-sm text-foreground/90">{outfit.ai_suggestion}</p>
          </div>
        </div>
      )}

      <div>
        <h3 className="text-sm font-semibold text-muted-foreground mb-2">Peças do look</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {items.map(it => (
            <button
              key={it.id}
              onClick={() => navigate(`/item/${it.id}`)}
              className="rounded-xl overflow-hidden border border-border bg-card text-left"
            >
              <div className="aspect-[3/4] bg-muted">
                <Image src={it.image_url} alt={it.name} className="w-full h-full" fittingType="fill" />
              </div>
              <p className="p-2 text-xs font-medium text-foreground truncate">{it.name}</p>
            </button>
          ))}
        </div>
      </div>

      <Button variant="outline" onClick={handleDelete} disabled={deleting} className="w-full gap-2 text-destructive hover:text-destructive">
        {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
        Excluir look
      </Button>
    </div>
  );
}