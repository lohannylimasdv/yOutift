import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Camera, ImagePlus, Loader2, Check, Sparkles, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Image as ImageIcon } from '@/components/ui/image';
import { useNavigate } from 'react-router-dom';

export default function AddItem() {
  const [imagePreview, setImagePreview] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);
  const navigate = useNavigate();

  const handleFile = async (file) => {
    if (!file) return;
    setError(null);
    setResult(null);
    setImagePreview(null);
    setAnalyzing(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setImagePreview(file_url);

      const response = await base44.functions.invoke('analyzeClothing', { image_url: file_url });
      const analysis = response.data;
      if (analysis.error) throw new Error(analysis.error);
      setResult({ ...analysis, image_url: file_url });
    } catch (e) {
      setError(e.message || 'Erro ao analisar a peça');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSave = async () => {
    if (!result) return;
    setSaving(true);
    try {
      await base44.entities.ClothingItem.create({
        name: result.name,
        image_url: result.image_url,
        category: result.category,
        color: result.color,
        color_family: result.color_family,
        style: result.style,
        season: result.season,
        ai_description: result.ai_description,
      });
      navigate('/');
    } catch (e) {
      setError(e.message || 'Erro ao salvar');
    } finally {
      setSaving(false);
    }
  };

  const reset = () => {
    setImagePreview(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-foreground">Adicionar peça</h2>
        <p className="text-sm text-muted-foreground">A IA analisa cor, estilo e categoria automaticamente</p>
      </div>

      {!imagePreview && !analyzing && (
        <div className="space-y-3">
          <button
            onClick={() => cameraInputRef.current?.click()}
            className="w-full p-8 rounded-2xl border-2 border-dashed border-border hover:border-primary hover:bg-accent/50 transition-all flex flex-col items-center gap-3 group"
          >
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
              <Camera className="w-6 h-6 text-primary" />
            </div>
            <div className="text-center">
              <p className="font-medium text-foreground">Tirar foto</p>
              <p className="text-xs text-muted-foreground">Use a câmera</p>
            </div>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full p-8 rounded-2xl border-2 border-dashed border-border hover:border-primary hover:bg-accent/50 transition-all flex flex-col items-center gap-3 group"
          >
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
              <ImagePlus className="w-6 h-6 text-primary" />
            </div>
            <div className="text-center">
              <p className="font-medium text-foreground">Escolher da galeria</p>
              <p className="text-xs text-muted-foreground">Suba uma imagem</p>
            </div>
          </button>
        </div>
      )}

      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />

      {analyzing && (
        <div className="flex flex-col items-center justify-center py-16 gap-4">
          {imagePreview && (
            <div className="w-40 h-52 rounded-2xl overflow-hidden border border-border shadow-md">
              <ImageIcon src={imagePreview} alt="preview" className="w-full h-full" fittingType="fill" />
            </div>
          )}
          <div className="flex items-center gap-2 text-primary">
            <Loader2 className="w-5 h-5 animate-spin" />
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <p className="text-sm text-muted-foreground">IA analisando sua peça...</p>
        </div>
      )}

      {result && !analyzing && (
        <div className="space-y-4">
          <div className="flex gap-3">
            <div className="w-24 h-32 rounded-xl overflow-hidden border border-border shadow-sm flex-shrink-0">
              <ImageIcon src={imagePreview} alt={result.name} className="w-full h-full" fittingType="fill" />
            </div>
            <div className="flex-1 space-y-2">
              <div className="flex items-start justify-between">
                <h3 className="font-semibold text-foreground">{result.name}</h3>
                <button onClick={reset} className="text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-muted-foreground">{result.ai_description}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <InfoChip label="Categoria" value={result.category} />
            <InfoChip label="Cor" value={result.color} />
            <InfoChip label="Estilo" value={result.style} />
            <InfoChip label="Estação" value={result.season} />
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={reset} className="flex-1">Descartar</Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1 gap-2">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              {saving ? 'Salvando...' : 'Salvar peça'}
            </Button>
          </div>
        </div>
      )}

      {error && !analyzing && (
        <div className="p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm">
          {error}
        </div>
      )}
    </div>
  );
}

function InfoChip({ label, value }) {
  return (
    <div className="p-2.5 rounded-xl bg-card border border-border">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="text-sm font-medium text-foreground capitalize">{value}</p>
    </div>
  );
}