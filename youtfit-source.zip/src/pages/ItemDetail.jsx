import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useParams, useNavigate } from 'react-router-dom';
import { Image } from '@/components/ui/image';
import { ArrowLeft, Trash2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const categoryLabels = {
  top: 'Tops', bottom: 'Calças/Saias', outerwear: 'Casacos', dress: 'Vestidos',
  shoes: 'Calçados', accessory: 'Acessórios', other: 'Outros',
};
const styleLabels = {
  casual: 'Casual', formal: 'Formal', sporty: 'Esportivo', streetwear: 'Streetwear',
  bohemian: 'Boêmio', classic: 'Clássico', trendy: 'Trendy', minimalist: 'Minimalista', vintage: 'Vintage',
};
const seasonLabels = {
  spring: 'Primavera', summer: 'Verão', fall: 'Outono', winter: 'Inverno', all: 'Todas',
};

export default function ItemDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [item, setItem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.ClothingItem.get(id);
        setItem(data);
      } catch (e) {
        setItem(null);
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await base44.entities.ClothingItem.delete(id);
      navigate('/');
    } catch (e) {
      setDeleting(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;
  }
  if (!item) {
    return <p className="text-center text-muted-foreground py-20">Peça não encontrada</p>;
  }

  return (
    <div className="space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="w-4 h-4" /> Voltar
      </button>

      <div className="rounded-2xl overflow-hidden border border-border shadow-sm aspect-[3/4] max-h-[60vh] bg-muted">
        <Image src={item.image_url} alt={item.name} className="w-full h-full" fittingType="fill" />
      </div>

      <div>
        <h2 className="text-xl font-bold text-foreground">{item.name}</h2>
        {item.ai_description && <p className="text-sm text-muted-foreground mt-1">{item.ai_description}</p>}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Detail label="Categoria" value={categoryLabels[item.category] || item.category} />
        <Detail label="Cor" value={item.color} />
        <Detail label="Família de cor" value={item.color_family} />
        <Detail label="Estilo" value={styleLabels[item.style] || item.style} />
        <Detail label="Estação" value={seasonLabels[item.season] || item.season} />
      </div>

      <Button variant="outline" onClick={handleDelete} disabled={deleting} className="w-full gap-2 text-destructive hover:text-destructive">
        {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
        Excluir peça
      </Button>
    </div>
  );
}

function Detail({ label, value }) {
  return (
    <div className="p-3 rounded-xl bg-card border border-border">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="text-sm font-medium text-foreground capitalize">{value}</p>
    </div>
  );
}