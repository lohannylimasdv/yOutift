import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { User, Mail, LogOut, Shirt, Sparkles, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

export default function Profile() {
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState({ items: 0, outfits: 0 });
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      try {
        const u = await base44.auth.me();
        setUser(u);
        const [items, outfits] = await Promise.all([
          base44.entities.ClothingItem.list(),
          base44.entities.Outfit.list(),
        ]);
        setStats({ items: items.length, outfits: outfits.length });
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  const handleLogout = async () => {
    await base44.auth.logout();
    window.location.href = '/login';
  };

  return (
    <div className="space-y-5">
      <h2 className="text-xl font-bold text-foreground">Perfil</h2>

      {/* Profile card */}
      <div className="p-5 rounded-2xl bg-gradient-to-br from-primary/10 to-accent border border-primary/20">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-2xl font-bold">
            {user?.full_name?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || <User className="w-7 h-7" />}
          </div>
          <div className="min-w-0">
            <p className="font-semibold text-foreground truncate">
              {user?.full_name || 'Seu perfil'}
            </p>
            <p className="text-sm text-muted-foreground flex items-center gap-1 truncate">
              <Mail className="w-3 h-3 flex-shrink-0" />
              {user?.email || ''}
            </p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 rounded-2xl bg-card border border-border text-center">
          <Shirt className="w-6 h-6 text-primary mx-auto mb-2" />
          <p className="text-2xl font-bold text-foreground">{stats.items}</p>
          <p className="text-xs text-muted-foreground">Peças</p>
        </div>
        <div className="p-4 rounded-2xl bg-card border border-border text-center">
          <Sparkles className="w-6 h-6 text-primary mx-auto mb-2" />
          <p className="text-2xl font-bold text-foreground">{stats.outfits}</p>
          <p className="text-xs text-muted-foreground">Looks</p>
        </div>
      </div>

      {/* Style summary */}
      <div className="p-4 rounded-2xl bg-card border border-border space-y-2">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-primary" />
          <p className="font-medium text-foreground text-sm">yOutfit</p>
        </div>
        <p className="text-xs text-muted-foreground">
          Seu guarda-roupa inteligente. A IA analisa suas peças e cria combinações perfeitas pra você.
        </p>
      </div>

      <Button variant="outline" onClick={handleLogout} className="w-full gap-2 text-destructive hover:text-destructive">
        <LogOut className="w-4 h-4" />
        Sair
      </Button>
    </div>
  );
}